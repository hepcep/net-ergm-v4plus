#include "glpk.h"
#include <R.h>
#include <Rinternals.h>

void Rglpk_initialize(void);
void Rglpk_error_hook(void *in);
